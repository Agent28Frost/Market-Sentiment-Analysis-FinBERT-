import csv
import re
import time
from pathlib import Path
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import quote, urlparse

import feedparser
import requests
from bs4 import BeautifulSoup

import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification


# =========================================================
# CONFIG
# =========================================================
MODEL_NAME = "yiyanghkust/finbert-tone"
RUN_SANITY_TEST = False

TITLE_WEIGHT = 0.4
CONTENT_WEIGHT = 0.6
REQUEST_TIMEOUT = 10
NUM_ARTICLES_PER_QUERY = 10
ARTICLE_POSITIVE_THRESHOLD = 0.25
ARTICLE_NEGATIVE_THRESHOLD = -0.25
MARKET_BULLISH_THRESHOLD = 0.20
MARKET_BEARISH_THRESHOLD = -0.20

# Which market to analyze: ES, NQ, GC, CL
TARGET_ASSET = "ES"

# CSV output folder
OUTPUT_DIR = Path("sentiment_output")
OUTPUT_DIR.mkdir(exist_ok=True)


# =========================================================
# ASSET PRESETS
# =========================================================
ASSET_PRESETS = {
    "ES": {
        "name": "S&P 500",
        "queries": [
            "S&P 500 futures",
            "ES futures market",
            "US stock futures",
            "Federal Reserve stocks",
            "Treasury yields equities",
            "CPI stocks market",
            "risk sentiment US equities",
            "stock market selloff",
            "equities decline",
            "risk-off sentiment",
            "market downturn",
            "stocks fall",
        ],
    },
    "NQ": {
        "name": "Nasdaq 100",
        "queries": [
            "Nasdaq futures",
            "NQ futures market",
            "technology stocks market",
            "semiconductor stocks outlook",
            "Treasury yields tech stocks",
            "Federal Reserve Nasdaq",
            "mega cap earnings outlook",
        ],
    },
    "GC": {
        "name": "Gold Futures",
        "queries": [
            "gold futures",
            "gold price outlook",
            "XAUUSD market",
            "Fed rates gold",
            "US dollar gold market",
            "Treasury yields gold",
            "safe haven demand gold",
        ],
    },
    "CL": {
        "name": "Crude Oil Futures",
        "queries": [
            "crude oil futures",
            "WTI oil market",
            "Brent crude outlook",
            "OPEC oil production",
            "oil supply disruption",
            "energy demand crude oil",
            "geopolitical risk oil",
        ],
    },
}


# =========================================================
# MODEL LOAD
# =========================================================
print("Loading FinBERT model...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME)
model.eval()


# =========================================================
# HELPERS
# =========================================================
def clean_text(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def parse_published_datetime(published_str: str):
    if not published_str:
        return None
    try:
        dt = parsedate_to_datetime(published_str)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def utc_now():
    return datetime.now(timezone.utc)


def hours_since(dt):
    if not dt:
        return None
    return (utc_now() - dt).total_seconds() / 3600.0


def extract_domain(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""


def fetch_article_content(url: str) -> str:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        )
    }

    try:
        response = requests.get(url, timeout=REQUEST_TIMEOUT, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")

        for tag in soup(["script", "style", "noscript"]):
            tag.decompose()

        paragraphs = soup.find_all("p")
        content = " ".join(p.get_text(" ", strip=True) for p in paragraphs)
        return clean_text(content)
    except requests.RequestException:
        return ""


def fetch_news(query: str, num_articles: int = 10):
    rss_url = f"https://news.google.com/rss/search?q={quote(query)}"
    feed = feedparser.parse(rss_url)
    news_items = feed.entries[:num_articles]

    articles = []
    for item in news_items:
        title = clean_text(getattr(item, "title", ""))
        link = getattr(item, "link", "")
        published = getattr(item, "published", "")
        published_dt = parse_published_datetime(published)
        content = fetch_article_content(link)

        articles.append(
            {
                "query": query,
                "title": title,
                "link": link,
                "domain": extract_domain(link),
                "published": published,
                "published_dt": published_dt,
                "content": content,
            }
        )

    return articles


def deduplicate_articles(articles):
    """
    Deduplicate mainly by normalized title.
    Fallback includes link in the key.
    """
    seen = set()
    deduped = []

    for article in articles:
        title_key = clean_text(article["title"]).lower()
        link_key = article["link"].strip().lower()
        key = (title_key, link_key)

        if key in seen:
            continue

        seen.add(key)
        deduped.append(article)

    return deduped


# =========================================================
# FINBERT SENTIMENT
# =========================================================
def split_for_finbert(text: str, max_words: int = 220):
    text = clean_text(text)
    if not text:
        return []

    words = text.split()
    chunks = []

    for i in range(0, len(words), max_words):
        chunk = " ".join(words[i:i + max_words]).strip()
        if chunk:
            chunks.append(chunk)

    return chunks


def canonicalize_finbert_label(label: str) -> str:
    normalized = str(label).strip().lower()
    label_map = {
        "positive": "Positive",
        "negative": "Negative",
        "neutral": "Neutral",
    }
    return label_map.get(normalized, str(label).strip())


def get_model_label(id2label: dict, index: int) -> str:
    raw_label = id2label.get(index)
    if raw_label is None:
        raw_label = id2label.get(str(index), str(index))
    return canonicalize_finbert_label(raw_label)


def finbert_predict(text: str):
    """
    Returns:
        score: float in [-1, 1]
        label: Positive / Negative / Neutral
        confidence: highest class probability
        probabilities: dict
    """
    text = clean_text(text)
    if not text:
        return 0.0, "Neutral", 0.0, {
            "Positive": 0.0,
            "Negative": 0.0,
            "Neutral": 1.0,
        }

    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=512,
        padding=True,
    )

    with torch.no_grad():
        outputs = model(**inputs)

    probs = torch.softmax(outputs.logits, dim=1).cpu().numpy()[0]
    id2label = model.config.id2label or {}
    prob_map = {"Positive": 0.0, "Negative": 0.0, "Neutral": 0.0}

    for i in range(len(probs)):
        model_label = get_model_label(id2label, i)
        prob_map[model_label] = float(probs[i])

    max_idx = int(np.argmax(probs))
    label = get_model_label(id2label, max_idx)
    confidence = float(probs[max_idx])

    # Core sentiment measure
    sentiment_index = prob_map["Positive"] - prob_map["Negative"]

    return sentiment_index, label, confidence, prob_map


def run_sentiment_sanity_test():
    print("\nRunning FinBERT sanity test...")

    examples = [
        "Stocks surge after softer inflation data boosts rate-cut hopes.",
        "Markets tumble as recession fears intensify and earnings disappoint.",
        "Traders await the Federal Reserve decision with little conviction.",
    ]

    for idx, text in enumerate(examples, start=1):
        sentiment_index, label, confidence, prob_map = finbert_predict(text)
        print("\n" + "-" * 100)
        print(f"Sanity test {idx}")
        print(f"Text: {text}")
        print(f"Label: {label}")
        print(f"Sentiment index: {sentiment_index:.4f}")
        print(f"Confidence: {confidence:.4f}")
        print(
            "Probabilities: "
            f"Positive={prob_map['Positive']:.4f}, "
            f"Negative={prob_map['Negative']:.4f}, "
            f"Neutral={prob_map['Neutral']:.4f}"
        )


def analyze_long_text(text: str):
    chunks = split_for_finbert(text)
    if not chunks:
        return 0.0, "Neutral", 0.0

    scores = []
    confidences = []

    for chunk in chunks:
        score, _, confidence, _ = finbert_predict(chunk)
        scores.append(score)
        confidences.append(confidence)

    avg_score = float(np.mean(scores))
    avg_conf = float(np.mean(confidences))

    if avg_score > ARTICLE_POSITIVE_THRESHOLD:
        label = "Positive"
    elif avg_score < ARTICLE_NEGATIVE_THRESHOLD:
        label = "Negative"
    else:
        label = "Neutral"

    return avg_score, label, avg_conf


def analyze_article(article: dict):
    title_score, title_label, title_conf = analyze_long_text(article["title"])

    if article["content"]:
        content_score, content_label, content_conf = analyze_long_text(article["content"])
        sentiment_index = (TITLE_WEIGHT * title_score) + (CONTENT_WEIGHT * content_score)
        confidence = (TITLE_WEIGHT * title_conf) + (CONTENT_WEIGHT * content_conf)
    else:
        content_score, content_label, content_conf = 0.0, "Neutral", 0.0
        sentiment_index = title_score
        confidence = title_conf

    if sentiment_index > ARTICLE_POSITIVE_THRESHOLD:
        combined_label = "Positive"
    elif sentiment_index < ARTICLE_NEGATIVE_THRESHOLD:
        combined_label = "Negative"
    else:
        combined_label = "Neutral"

    return {
        "title_score": title_score,
        "title_label": title_label,
        "title_confidence": title_conf,
        "content_score": content_score,
        "content_label": content_label,
        "content_confidence": content_conf,
        "sentiment_index": sentiment_index,
        "combined_label": combined_label,
        "combined_confidence": confidence,
    }


# =========================================================
# AGGREGATION
# =========================================================
def classify_market_bias(sentiment_index: float) -> str:
    if sentiment_index > MARKET_BULLISH_THRESHOLD:
        return "Bullish"
    if sentiment_index < MARKET_BEARISH_THRESHOLD:
        return "Bearish"
    return "Neutral"


def aggregate_articles(analyzed_articles):
    counts = {"Positive": 0, "Negative": 0, "Neutral": 0}
    scores = []
    confidences = []

    for article in analyzed_articles:
        label = article["analysis"]["combined_label"]
        score = article["analysis"]["sentiment_index"]
        conf = article["analysis"]["combined_confidence"]

        counts[label] += 1
        scores.append(score)
        confidences.append(conf)

    total = len(analyzed_articles)
    aggregate_index = float(np.mean(scores)) if scores else 0.0
    avg_confidence = float(np.mean(confidences)) if confidences else 0.0
    market_bias = classify_market_bias(aggregate_index)

    if scores:
        print("\nSentiment score distribution:")
        print(f"Min sentiment_index: {min(scores):.4f}")
        print(f"Max sentiment_index: {max(scores):.4f}")
        print(f"Avg sentiment_index: {np.mean(scores):.4f}")

    return {
        "total_articles": total,
        "positive_count": counts["Positive"],
        "negative_count": counts["Negative"],
        "neutral_count": counts["Neutral"],
        "aggregate_sentiment_index": aggregate_index,
        "average_confidence": avg_confidence,
        "market_bias": market_bias,
    }


# =========================================================
# CSV EXPORT
# =========================================================
def export_article_csv(asset_code: str, analyzed_articles: list):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = OUTPUT_DIR / f"{asset_code}_articles_{timestamp}.csv"

    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "asset",
            "query",
            "title",
            "domain",
            "published",
            "hours_old",
            "link",
            "title_label",
            "title_score",
            "content_label",
            "content_score",
            "combined_label",
            "sentiment_index",
            "confidence",
            "content_available",
        ])

        for article in analyzed_articles:
            analysis = article["analysis"]
            age_hours = hours_since(article["published_dt"])
            writer.writerow([
                asset_code,
                article["query"],
                article["title"],
                article["domain"],
                article["published"],
                f"{age_hours:.2f}" if age_hours is not None else "",
                article["link"],
                analysis["title_label"],
                f"{analysis['title_score']:.6f}",
                analysis["content_label"],
                f"{analysis['content_score']:.6f}",
                analysis["combined_label"],
                f"{analysis['sentiment_index']:.6f}",
                f"{analysis['combined_confidence']:.6f}",
                bool(article["content"]),
            ])

    return filepath


def export_summary_csv(asset_code: str, asset_name: str, summary: dict):
    filepath = OUTPUT_DIR / f"{asset_code}_summary.csv"
    file_exists = filepath.exists()

    with open(filepath, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)

        if not file_exists:
            writer.writerow([
                "timestamp",
                "asset",
                "asset_name",
                "total_articles",
                "positive_count",
                "negative_count",
                "neutral_count",
                "aggregate_sentiment_index",
                "average_confidence",
                "market_bias",
            ])

        writer.writerow([
            datetime.now().isoformat(timespec="seconds"),
            asset_code,
            asset_name,
            summary["total_articles"],
            summary["positive_count"],
            summary["negative_count"],
            summary["neutral_count"],
            f"{summary['aggregate_sentiment_index']:.6f}",
            f"{summary['average_confidence']:.6f}",
            summary["market_bias"],
        ])

    return filepath


# =========================================================
# DISPLAY
# =========================================================
def print_article(article: dict, idx: int):
    analysis = article["analysis"]
    age_hours = hours_since(article["published_dt"])

    print("\n" + "=" * 100)
    print(f"Article {idx}")
    print(f"Title: {article['title']}")
    print(f"Query: {article['query']}")
    print(f"Source: {article['domain']}")
    print(f"Published: {article['published']}")
    if age_hours is not None:
        print(f"Age (hours): {age_hours:.2f}")
    print(f"Link: {article['link']}")

    print(f"\nTitle sentiment:   {analysis['title_label']} ({analysis['title_score']:.4f})")

    if article["content"]:
        print(f"Content sentiment: {analysis['content_label']} ({analysis['content_score']:.4f})")
    else:
        print("Content sentiment: unavailable (title-only fallback)")

    print(
        f"Combined sentiment: {analysis['combined_label']} "
        f"(sentiment_index={analysis['sentiment_index']:.4f}, "
        f"confidence={analysis['combined_confidence']:.4f})"
    )


def print_summary(asset_code: str, asset_name: str, summary: dict):
    total = summary["total_articles"]

    print("\n" + "-" * 100)
    print(f"Market Sentiment Summary | {asset_code} | {asset_name}")
    print("-" * 100)
    print(f"Total unique articles analyzed: {total}")

    if total:
        pos_pct = (summary["positive_count"] / total) * 100
        neg_pct = (summary["negative_count"] / total) * 100
        neu_pct = (summary["neutral_count"] / total) * 100
    else:
        pos_pct = neg_pct = neu_pct = 0.0

    print(f"Positive: {summary['positive_count']} ({pos_pct:.2f}%)")
    print(f"Negative: {summary['negative_count']} ({neg_pct:.2f}%)")
    print(f"Neutral:  {summary['neutral_count']} ({neu_pct:.2f}%)")

    print(f"\nAggregate sentiment_index: {summary['aggregate_sentiment_index']:.4f}")
    print(f"Average confidence: {summary['average_confidence']:.4f}")
    print(f"Market bias: {summary['market_bias']}")


# =========================================================
# MAIN
# =========================================================
def main():
    asset_code = TARGET_ASSET.upper()

    if asset_code not in ASSET_PRESETS:
        raise ValueError(
            f"Unsupported asset '{TARGET_ASSET}'. "
            f"Choose one of: {', '.join(ASSET_PRESETS.keys())}"
        )

    asset = ASSET_PRESETS[asset_code]
    asset_name = asset["name"]
    queries = asset["queries"]

    print(f"\nRunning sentiment analysis for {asset_code} - {asset_name}")
    print(f"Queries: {len(queries)}")
    print(f"Articles per query: {NUM_ARTICLES_PER_QUERY}")

    all_articles = []

    for query in queries:
        print(f"\nFetching news for query: {query}")
        articles = fetch_news(query, NUM_ARTICLES_PER_QUERY)
        all_articles.extend(articles)
        time.sleep(0.5)

    print(f"\nFetched raw articles: {len(all_articles)}")
    unique_articles = deduplicate_articles(all_articles)
    print(f"After deduplication: {len(unique_articles)}")

    analyzed_articles = []

    for idx, article in enumerate(unique_articles, start=1):
        analysis = analyze_article(article)
        enriched = {**article, "analysis": analysis}
        analyzed_articles.append(enriched)
        print_article(enriched, idx)

    summary = aggregate_articles(analyzed_articles)
    print_summary(asset_code, asset_name, summary)

    article_csv = export_article_csv(asset_code, analyzed_articles)
    summary_csv = export_summary_csv(asset_code, asset_name, summary)

    print("\nCSV export complete.")
    print(f"Article-level CSV: {article_csv}")
    print(f"Rolling summary CSV: {summary_csv}")


if __name__ == "__main__":
    if RUN_SANITY_TEST:
        run_sentiment_sanity_test()
    main()
